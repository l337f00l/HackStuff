=========================
Nintendo Presents Logo Expansion Patch v1.2
By Ghettoyouth
v1.1 by Roy
v1.2 by telinc1
v1.3 by Blind Devil
=========================

Q: What will this patch do?
A: This patch will make the Nintendo Presents Logo
expand to a 64x64 sprite. Its graphics will come from
GFX file BD (by default), but you can change it to any
value between 00-FF. A sample ExGFX file is also
included.

Q: Credit needed?
A: Credit ghettoyouth.

---------------
VERSIONS
---------------
v1.3 (remoderation) - Blind Devil
Changed some hijack and code spots in order to make the patch compatible with AMK. Previously, if you
applied it and re-ran AMK, the game would crash before loading anything.

v1.2 - telinc1
Updated to Asar and added SA-1 compatibility. Also added in some extra defines to make configuration easier.

v1.1 - Roy
Some bugs that could corrupt the ROM are now fixed.

v1.0 - ghettoyouth
Original code.